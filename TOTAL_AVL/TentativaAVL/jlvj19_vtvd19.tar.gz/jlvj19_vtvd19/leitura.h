/* GRR20190372 & GRR20190367 */
/* jlvj19      &      vtvd19 */

#ifndef __LEITURA__
#define __LEITURA__

#include "libAVL.h"

/* Le o arquivo redirecionado para ao programa */
tNodo *lerEntrada(tNodo *nodo);

#endif